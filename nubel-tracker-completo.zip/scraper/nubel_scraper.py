#!/usr/bin/env python3
"""
nubel_scraper.py
Scraper diario para Nubel Tracker.
- Scrapea pronósticos de Subrayado.com.uy (Nubel Cisneros)
- Obtiene datos reales de Open-Meteo Archive
- Escribe a Supabase

Cron: todos los días a las 15:00 UTC (12:00 Uruguay)
"""

import os
import json
import re
import time
import logging
from datetime import date, timedelta
from typing import Optional

import requests
from bs4 import BeautifulSoup

# ─── CONFIG ──────────────────────────────────────────────────────────────────
SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_KEY = os.environ["SUPABASE_SERVICE_KEY"]   # service_role key

HEADERS_SUPA = {
    "apikey": SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}",
    "Content-Type": "application/json",
    "Prefer": "resolution=merge-duplicates",   # upsert por UNIQUE
}

# Estaciones INUMET por zona (coordenadas Open-Meteo)
ZONAS_ESTACIONES = {
    "metro": [(-34.84, -56.01), (-34.85, -56.21)],
    "norte": [(-30.40, -56.51), (-30.91, -55.55), (-31.38, -57.97)],
    "sur":   [(-34.46, -57.84), (-33.38, -56.52), (-33.25, -58.08)],
    "este":  [(-34.48, -54.33), (-32.37, -54.17), (-34.91, -54.96)],
    "oeste": [(-32.32, -58.08), (-32.69, -57.63)],
}

# URLs de artículos de Subrayado que Nubel publica con temperaturas por zona
SUBRAYADO_TAG = "https://www.subrayado.com.uy/nubel-cisneros-a12869"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)


# ─── SUPABASE HELPERS ────────────────────────────────────────────────────────
def supa_upsert(table: str, rows: list[dict]) -> int:
    if not rows:
        return 0
    url = f"{SUPABASE_URL}/rest/v1/{table}"
    res = requests.post(url, headers=HEADERS_SUPA, json=rows, timeout=30)
    if not res.ok:
        log.error("Supabase upsert error %s: %s", res.status_code, res.text[:200])
        return 0
    return len(rows)


def supa_log(estado: str, pron: int, reales: int, detalle: str = ""):
    url = f"{SUPABASE_URL}/rest/v1/scraper_log"
    requests.post(url, headers=HEADERS_SUPA, json=[{
        "estado": estado,
        "pronosticos_insertados": pron,
        "reales_insertados": reales,
        "detalle": detalle[:1000],
    }], timeout=15)


# ─── SCRAPER SUBRAYADO ───────────────────────────────────────────────────────
def fetch_subrayado_article_urls(max_articles: int = 5) -> list[dict]:
    """Obtiene las URLs de los artículos más recientes de Nubel en Subrayado."""
    try:
        res = requests.get(SUBRAYADO_TAG, timeout=15,
                           headers={"User-Agent": "Mozilla/5.0 NubelTracker/1.0"})
        soup = BeautifulSoup(res.text, "html.parser")
        articles = []
        for a in soup.select("a[href*='-n']"):
            href = a.get("href", "")
            if "nubel" in href.lower() or (
                "/n" in href and any(k in a.get_text().lower()
                                     for k in ["temperatura", "máxima", "calor", "frío", "pronóstico", "tiempo"])
            ):
                full = href if href.startswith("http") else f"https://www.subrayado.com.uy{href}"
                if full not in [x["url"] for x in articles]:
                    articles.append({"url": full, "title": a.get_text(strip=True)})
            if len(articles) >= max_articles * 3:
                break
        return articles[:max_articles]
    except Exception as e:
        log.error("Error fetching Subrayado index: %s", e)
        return []


def parse_temperatures_from_article(url: str) -> Optional[dict]:
    """
    Parsea temperaturas por zona de un artículo de Subrayado.
    Retorna dict con fecha_pronostico, y lista de entradas {fecha_dia, zona, max, min}
    """
    try:
        res = requests.get(url, timeout=15,
                           headers={"User-Agent": "Mozilla/5.0 NubelTracker/1.0"})
        soup = BeautifulSoup(res.text, "html.parser")
        text = soup.get_text()

        # Extraer fecha del artículo (ej: "14 de marzo de 2026")
        date_match = re.search(
            r"(\d{1,2}) de (\w+) de (\d{4})",
            text
        )
        if not date_match:
            return None

        MESES = {"enero":1,"febrero":2,"marzo":3,"abril":4,"mayo":5,"junio":6,
                 "julio":7,"agosto":8,"septiembre":9,"octubre":10,"noviembre":11,"diciembre":12}
        d, m_str, y = date_match.groups()
        mes_num = MESES.get(m_str.lower())
        if not mes_num:
            return None
        fecha_pub = date(int(y), mes_num, int(d))

        # Patrones de temperatura por zona
        # Ej: "La máxima para el norte es de 33ºC y la mínima de 16ºC"
        # Ej: "NORTE: MÁX.: 33 °C - MÍN.: 16 °C"
        # Ej: "Norte: Mínima 18ºC | Máxima 35ºC"
        # Ej: "Área metropolitana: Mínima 20ºC | Máxima 29ºC"

        ZONA_PATTERNS = [
            ("norte",  r"(?:norte|NORTE)[^\d]*?(?:máx|MAX|máxima)[^\d]*?(\d+)[°º]"),
            ("sur",    r"(?:sur|SUR)[^\d]*?(?:máx|MAX|máxima)[^\d]*?(\d+)[°º]"),
            ("este",   r"(?:este|ESTE)[^\d]*?(?:máx|MAX|máxima)[^\d]*?(\d+)[°º]"),
            ("oeste",  r"(?:oeste|OESTE)[^\d]*?(?:máx|MAX|máxima)[^\d]*?(\d+)[°º]"),
            ("metro",  r"(?:metropolitana|METROPOLITANA|metro)[^\d]*?(?:máx|MAX|máxima)[^\d]*?(\d+)[°º]"),
        ]
        ZONA_MIN_PATTERNS = [
            ("norte",  r"(?:norte|NORTE)[^\d]*?(?:mín|MIN|mínima)[^\d]*?(\d+)[°º]"),
            ("sur",    r"(?:sur|SUR)[^\d]*?(?:mín|MIN|mínima)[^\d]*?(\d+)[°º]"),
            ("este",   r"(?:este|ESTE)[^\d]*?(?:mín|MIN|mínima)[^\d]*?(\d+)[°º]"),
            ("oeste",  r"(?:oeste|OESTE)[^\d]*?(?:mín|MIN|mínima)[^\d]*?(\d+)[°º]"),
            ("metro",  r"(?:metropolitana|METROPOLITANA|metro)[^\d]*?(?:mín|MIN|mínima)[^\d]*?(\d+)[°º]"),
        ]

        # Buscar bloques por día (ej: "Temperaturas para el domingo 8:" o "Este sábado")
        day_blocks = re.split(
            r"(?:Temperaturas para el|Este|El)\s+(?:domingo|lunes|martes|miércoles|jueves|viernes|sábado)\s+(\d+)[:\.]?",
            text
        )

        entries = []
        # Estrategia simple: buscar todos los valores por zona en el texto completo
        # y agrupar por día mencionado cercano al bloque

        # Detectar fechas mencionadas en el artículo (ej: "domingo 8", "lunes 9")
        DAY_NAMES = {"domingo":"sun","lunes":"mon","martes":"tue","miércoles":"wed",
                     "jueves":"thu","viernes":"fri","sábado":"sat"}
        mentioned_days = re.findall(
            r"(?:domingo|lunes|martes|miércoles|jueves|viernes|sábado)\s+(\d+)",
            text, re.IGNORECASE
        )

        # Extraer todos los maxs/mins por zona del texto completo
        # (aproximación: tomar el primer valor encontrado para cada zona)
        zona_data = {}
        for zona, pat in ZONA_PATTERNS:
            matches = re.findall(pat, text, re.IGNORECASE)
            if matches:
                zona_data.setdefault(zona, {})["max"] = int(matches[0])
        for zona, pat in ZONA_MIN_PATTERNS:
            matches = re.findall(pat, text, re.IGNORECASE)
            if matches:
                zona_data.setdefault(zona, {})["min"] = int(matches[0])

        if not zona_data or len(zona_data) < 3:
            return None

        # Si hay días mencionados, asignar a esos días; sino usar fecha_pub
        target_days = []
        for day_str in mentioned_days[:3]:  # máx 3 días hacia adelante
            day_num = int(day_str)
            # Determinar mes correcto
            try:
                target = date(fecha_pub.year, fecha_pub.month, day_num)
                if target < fecha_pub:
                    # siguiente mes
                    if fecha_pub.month == 12:
                        target = date(fecha_pub.year + 1, 1, day_num)
                    else:
                        target = date(fecha_pub.year, fecha_pub.month + 1, day_num)
                target_days.append(target)
            except ValueError:
                pass

        if not target_days:
            target_days = [fecha_pub]

        # Crear una entrada por zona para el día principal (primero mencionado)
        fecha_dia = target_days[0]
        for zona, vals in zona_data.items():
            if "max" in vals:
                entries.append({
                    "fecha_dia":        fecha_dia.isoformat(),
                    "fecha_pronostico": fecha_pub.isoformat(),
                    "zona":             zona,
                    "max_nubel":        vals.get("max"),
                    "min_nubel":        vals.get("min"),
                    "url_fuente":       url,
                })

        return {"fecha_pub": fecha_pub, "entries": entries} if entries else None

    except Exception as e:
        log.error("Error parsing %s: %s", url, e)
        return None


# ─── DATOS REALES (Open-Meteo Archive) ───────────────────────────────────────
def fetch_real_zona(zona: str, fecha: date) -> Optional[dict]:
    """Promedia las estaciones de una zona para obtener max/min real."""
    estaciones = ZONAS_ESTACIONES.get(zona, [])
    maxs, mins = [], []
    for lat, lon in estaciones:
        fecha_str = fecha.isoformat()
        url = (
            f"https://archive-api.open-meteo.com/v1/archive"
            f"?latitude={lat}&longitude={lon}"
            f"&start_date={fecha_str}&end_date={fecha_str}"
            f"&daily=temperature_2m_max,temperature_2m_min"
            f"&timezone=America%2FMontevideo"
        )
        try:
            r = requests.get(url, timeout=20)
            if r.ok:
                d = r.json()
                mx = d["daily"]["temperature_2m_max"][0]
                mn = d["daily"]["temperature_2m_min"][0]
                if mx is not None:
                    maxs.append(mx)
                if mn is not None:
                    mins.append(mn)
        except Exception as e:
            log.warning("Open-Meteo error %s %s: %s", zona, fecha_str, e)
        time.sleep(0.3)  # rate limiting

    if not maxs:
        return None
    return {
        "fecha":    fecha.isoformat(),
        "zona":     zona,
        "max_real": round(sum(maxs) / len(maxs), 1),
        "min_real": round(sum(mins) / len(mins), 1) if mins else None,
        "fuente":   "Open-Meteo/INUMET",
    }


def fetch_reales_para_fecha(target_date: date) -> list[dict]:
    """Obtiene datos reales de todas las zonas para una fecha."""
    # Open-Meteo Archive solo tiene datos hasta 2-3 días antes de hoy
    today = date.today()
    if (today - target_date).days < 2:
        log.info("Fecha %s muy reciente para Open-Meteo, omitiendo", target_date)
        return []
    results = []
    for zona in ZONAS_ESTACIONES:
        real = fetch_real_zona(zona, target_date)
        if real:
            results.append(real)
    return results


# ─── LÓGICA PRINCIPAL ────────────────────────────────────────────────────────
def run():
    today = date.today()
    yesterday = today - timedelta(days=1)
    two_days_ago = today - timedelta(days=2)

    log.info("=== Nubel Tracker Scraper — %s ===", today.isoformat())
    pronosticos_total = 0
    reales_total = 0
    errores = []

    # 1. PRONÓSTICOS: scrape los últimos artículos de Subrayado
    log.info("Scrapeando pronósticos de Subrayado...")
    article_urls = fetch_subrayado_article_urls(max_articles=5)
    log.info("Encontrados %d artículos", len(article_urls))

    all_pronosticos = []
    for art in article_urls:
        log.info("Parseando: %s", art["url"][:80])
        result = parse_temperatures_from_article(art["url"])
        if result and result["entries"]:
            log.info("  → %d entradas extraídas", len(result["entries"]))
            all_pronosticos.extend(result["entries"])
        else:
            log.info("  → Sin datos de temperatura por zona")
        time.sleep(1)

    if all_pronosticos:
        pronosticos_total = supa_upsert("nubel_pronosticos", all_pronosticos)
        log.info("Pronósticos guardados en Supabase: %d", pronosticos_total)

    # 2. DATOS REALES: para ayer y anteayer (datos ya disponibles en Open-Meteo)
    log.info("Obteniendo datos reales de Open-Meteo...")
    for target_date in [two_days_ago, yesterday]:
        log.info("Fetching datos reales para %s...", target_date.isoformat())
        reales = fetch_reales_para_fecha(target_date)
        if reales:
            n = supa_upsert("datos_reales", reales)
            reales_total += n
            log.info("  → %d filas guardadas", n)

    # 3. LOG
    estado = "ok" if not errores else "parcial"
    detalle = "; ".join(errores) if errores else f"OK — {len(article_urls)} artículos procesados"
    supa_log(estado, pronosticos_total, reales_total, detalle)
    log.info("=== Fin. Pronósticos: %d | Reales: %d ===", pronosticos_total, reales_total)


if __name__ == "__main__":
    run()
