-- ═══════════════════════════════════════════════════════════════
-- NUBEL TRACKER — Schema Supabase
-- Ejecutar en: Supabase Dashboard → SQL Editor
-- ═══════════════════════════════════════════════════════════════

-- 1. Pronósticos de Nubel Cisneros (Subrayado.com.uy)
CREATE TABLE IF NOT EXISTS nubel_pronosticos (
  id              BIGSERIAL PRIMARY KEY,
  fecha_dia       DATE        NOT NULL,   -- día al que aplica el pronóstico
  fecha_pronostico DATE       NOT NULL,   -- día en que Nubel lo publicó
  zona            TEXT        NOT NULL,   -- metro | norte | sur | este | oeste
  max_nubel       NUMERIC(4,1),           -- temperatura máxima pronosticada
  min_nubel       NUMERIC(4,1),           -- temperatura mínima pronosticada
  url_fuente      TEXT,                   -- URL del artículo en Subrayado
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (fecha_dia, zona)                -- un registro por día+zona
);

-- 2. Datos reales (AccuWeather / INUMET)
CREATE TABLE IF NOT EXISTS datos_reales (
  id         BIGSERIAL PRIMARY KEY,
  fecha      DATE        NOT NULL,
  zona       TEXT        NOT NULL,        -- metro | norte | sur | este | oeste
  max_real   NUMERIC(4,1),
  min_real   NUMERIC(4,1),
  fuente     TEXT DEFAULT 'AccuWeather',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (fecha, zona)
);

-- 3. Log de ejecuciones del scraper
CREATE TABLE IF NOT EXISTS scraper_log (
  id          BIGSERIAL PRIMARY KEY,
  ejecutado_en TIMESTAMPTZ DEFAULT NOW(),
  estado      TEXT,                       -- ok | error
  pronosticos_insertados INT DEFAULT 0,
  reales_insertados      INT DEFAULT 0,
  detalle     TEXT
);

-- ─── ÍNDICES ──────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_pronosticos_fecha_zona ON nubel_pronosticos (fecha_dia, zona);
CREATE INDEX IF NOT EXISTS idx_reales_fecha_zona      ON datos_reales (fecha, zona);

-- ─── ROW LEVEL SECURITY ───────────────────────────────────────
ALTER TABLE nubel_pronosticos ENABLE ROW LEVEL SECURITY;
ALTER TABLE datos_reales      ENABLE ROW LEVEL SECURITY;
ALTER TABLE scraper_log       ENABLE ROW LEVEL SECURITY;

-- Lectura pública (anon key)
CREATE POLICY "Lectura pública pronosticos" ON nubel_pronosticos
  FOR SELECT USING (true);

CREATE POLICY "Lectura pública reales" ON datos_reales
  FOR SELECT USING (true);

-- Escritura solo con service_role (GitHub Actions)
CREATE POLICY "Escritura service_role pronosticos" ON nubel_pronosticos
  FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Escritura service_role reales" ON datos_reales
  FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Escritura service_role log" ON scraper_log
  FOR ALL USING (auth.role() = 'service_role');

-- ─── DATOS HISTÓRICOS SEED (enero-marzo 2026) ─────────────────
-- Pronósticos
INSERT INTO nubel_pronosticos (fecha_dia, fecha_pronostico, zona, max_nubel, min_nubel, url_fuente) VALUES
-- 4 enero
('2026-01-04','2026-01-04','norte',34,15,'https://www.subrayado.com.uy/domingo-calido-caluroso-pasaje-nubosidad-se-inestabiliza-la-noche-la-costa-sureste-n996583'),
('2026-01-04','2026-01-04','sur',  30,15,'https://www.subrayado.com.uy/domingo-calido-caluroso-pasaje-nubosidad-se-inestabiliza-la-noche-la-costa-sureste-n996583'),
('2026-01-04','2026-01-04','este', 30,15,'https://www.subrayado.com.uy/domingo-calido-caluroso-pasaje-nubosidad-se-inestabiliza-la-noche-la-costa-sureste-n996583'),
('2026-01-04','2026-01-04','oeste',34,15,'https://www.subrayado.com.uy/domingo-calido-caluroso-pasaje-nubosidad-se-inestabiliza-la-noche-la-costa-sureste-n996583'),
('2026-01-04','2026-01-04','metro',28,18,'https://www.subrayado.com.uy/domingo-calido-caluroso-pasaje-nubosidad-se-inestabiliza-la-noche-la-costa-sureste-n996583'),
-- 25 enero
('2026-01-25','2026-01-25','norte',41,18,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-25','2026-01-25','sur',  39,18,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-25','2026-01-25','este', 37,18,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-25','2026-01-25','oeste',41,20,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-25','2026-01-25','metro',34,23,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
-- 26 enero
('2026-01-26','2026-01-25','norte',41,20,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-26','2026-01-25','sur',  40,20,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-26','2026-01-25','este', 38,20,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-26','2026-01-25','oeste',41,24,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
('2026-01-26','2026-01-25','metro',34,24,'https://www.subrayado.com.uy/continuan-las-altas-temperaturas-y-superaran-los-40c-algunas-zonas-segun-el-pronostico-nubel-cisneros-n998459'),
-- 1 febrero
('2026-02-01','2026-02-01','norte',39,16,'https://www.subrayado.com.uy/vuelven-subir-las-temperaturas-nubel-cisneros-preve-jornadas-calurosas-y-pesadas-este-domingo-n999012'),
('2026-02-01','2026-02-01','sur',  36,18,'https://www.subrayado.com.uy/vuelven-subir-las-temperaturas-nubel-cisneros-preve-jornadas-calurosas-y-pesadas-este-domingo-n999012'),
('2026-02-01','2026-02-01','este', 35,16,'https://www.subrayado.com.uy/vuelven-subir-las-temperaturas-nubel-cisneros-preve-jornadas-calurosas-y-pesadas-este-domingo-n999012'),
('2026-02-01','2026-02-01','oeste',38,18,'https://www.subrayado.com.uy/vuelven-subir-las-temperaturas-nubel-cisneros-preve-jornadas-calurosas-y-pesadas-este-domingo-n999012'),
('2026-02-01','2026-02-01','metro',30,20,'https://www.subrayado.com.uy/vuelven-subir-las-temperaturas-nubel-cisneros-preve-jornadas-calurosas-y-pesadas-este-domingo-n999012'),
-- 19 febrero
('2026-02-19','2026-02-19','norte',32,18,'https://www.subrayado.com.uy/jueves-inestable-tormentas-el-norte-y-calor-que-no-afloja-mira-el-pronostico-n1000409'),
('2026-02-19','2026-02-19','sur',  32,18,'https://www.subrayado.com.uy/jueves-inestable-tormentas-el-norte-y-calor-que-no-afloja-mira-el-pronostico-n1000409'),
('2026-02-19','2026-02-19','este', 30,18,'https://www.subrayado.com.uy/jueves-inestable-tormentas-el-norte-y-calor-que-no-afloja-mira-el-pronostico-n1000409'),
('2026-02-19','2026-02-19','oeste',34,18,'https://www.subrayado.com.uy/jueves-inestable-tormentas-el-norte-y-calor-que-no-afloja-mira-el-pronostico-n1000409'),
('2026-02-19','2026-02-19','metro',29,20,'https://www.subrayado.com.uy/jueves-inestable-tormentas-el-norte-y-calor-que-no-afloja-mira-el-pronostico-n1000409'),
-- 7 marzo
('2026-03-07','2026-03-07','norte',33,16,'https://www.subrayado.com.uy/tarde-sabado-calida-calurosa-temperaturas-frescas-la-noche-n1001742'),
('2026-03-07','2026-03-07','sur',  31,16,'https://www.subrayado.com.uy/tarde-sabado-calida-calurosa-temperaturas-frescas-la-noche-n1001742'),
('2026-03-07','2026-03-07','este', 30,16,'https://www.subrayado.com.uy/tarde-sabado-calida-calurosa-temperaturas-frescas-la-noche-n1001742'),
('2026-03-07','2026-03-07','oeste',34,16,'https://www.subrayado.com.uy/tarde-sabado-calida-calurosa-temperaturas-frescas-la-noche-n1001742'),
('2026-03-07','2026-03-07','metro',28,18,'https://www.subrayado.com.uy/tarde-sabado-calida-calurosa-temperaturas-frescas-la-noche-n1001742'),
-- 8 marzo
('2026-03-08','2026-03-08','norte',32,15,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-08','2026-03-08','sur',  31,15,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-08','2026-03-08','este', 30,15,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-08','2026-03-08','oeste',32,15,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-08','2026-03-08','metro',28,18,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
-- 9 marzo (pronóstico del 8)
('2026-03-09','2026-03-08','norte',32,14,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-09','2026-03-08','sur',  30,14,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-09','2026-03-08','este', 30,14,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-09','2026-03-08','oeste',32,16,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-09','2026-03-08','metro',27,18,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
-- 10 marzo (pronóstico del 8)
('2026-03-10','2026-03-08','norte',34,16,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-10','2026-03-08','sur',  32,16,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-10','2026-03-08','este', 30,16,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-10','2026-03-08','oeste',34,16,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
('2026-03-10','2026-03-08','metro',29,18,'https://www.subrayado.com.uy/dias-calidos-calurosos-y-noches-frescas-el-pronostico-nubel-cisneros-el-arranque-la-semana-n1001796'),
-- 14 marzo
('2026-03-14','2026-03-14','norte',35,18,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-14','2026-03-14','sur',  32,16,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-14','2026-03-14','este', 32,16,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-14','2026-03-14','oeste',34,16,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-14','2026-03-14','metro',29,20,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
-- 15 marzo (pronóstico del 14)
('2026-03-15','2026-03-14','norte',37,18,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-15','2026-03-14','sur',  33,18,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-15','2026-03-14','este', 32,16,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-15','2026-03-14','oeste',36,18,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-15','2026-03-14','metro',30,20,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
-- 16 marzo (pronóstico del 14)
('2026-03-16','2026-03-14','norte',39,20,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-16','2026-03-14','sur',  37,20,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-16','2026-03-14','este', 36,18,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-16','2026-03-14','oeste',39,22,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417'),
('2026-03-16','2026-03-14','metro',33,23,'https://www.subrayado.com.uy/fin-semana-disfrutar-al-aire-libre-temperaturas-elevadas-las-maximas-alcanzaran-los-37c-n1002417')
ON CONFLICT (fecha_dia, zona) DO NOTHING;

-- Datos reales (AccuWeather historical)
INSERT INTO datos_reales (fecha, zona, max_real, min_real, fuente) VALUES
-- Montevideo (metro)
('2026-01-04','metro',26.7,19.4,'AccuWeather'),
('2026-01-25','metro',34.4,22.8,'AccuWeather'),
('2026-01-26','metro',34.4,22.8,'AccuWeather'),
('2026-02-01','metro',28.9,18.9,'AccuWeather'),
('2026-02-19','metro',26.7,20.0,'AccuWeather'),
('2026-03-07','metro',23.9,20.0,'AccuWeather'),
('2026-03-08','metro',23.9,17.8,'AccuWeather'),
('2026-03-09','metro',23.9,17.2,'AccuWeather'),
('2026-03-10','metro',23.9,15.0,'AccuWeather'),
('2026-03-14','metro',26.1,13.9,'AccuWeather'),
('2026-03-15','metro',32.2,17.2,'AccuWeather'),
('2026-03-16','metro',31.7,22.2,'AccuWeather'),
-- Norte (Salto)
('2026-01-04','norte',33.3,15.0,'AccuWeather'),
('2026-01-25','norte',38.3,21.1,'AccuWeather'),
('2026-01-26','norte',38.3,22.2,'AccuWeather'),
('2026-02-01','norte',33.3,18.9,'AccuWeather'),
('2026-02-19','norte',28.9,18.9,'AccuWeather'),
('2026-03-07','norte',26.1,20.0,'AccuWeather'),
('2026-03-08','norte',27.2,17.2,'AccuWeather'),
('2026-03-09','norte',27.2,17.2,'AccuWeather'),
('2026-03-10','norte',27.2,16.1,'AccuWeather'),
('2026-03-14','norte',30.0,15.0,'AccuWeather'),
('2026-03-15','norte',32.2,15.0,'AccuWeather'),
('2026-03-16','norte',34.4,21.1,'AccuWeather'),
-- Oeste (Paysandú)
('2026-01-04','oeste',33.3,14.4,'AccuWeather'),
('2026-01-25','oeste',37.8,21.1,'AccuWeather'),
('2026-01-26','oeste',37.8,22.2,'AccuWeather'),
('2026-02-01','oeste',32.2,17.8,'AccuWeather'),
('2026-02-19','oeste',28.3,17.8,'AccuWeather'),
('2026-03-07','oeste',26.1,14.4,'AccuWeather'),
('2026-03-08','oeste',26.7,14.4,'AccuWeather'),
('2026-03-09','oeste',26.7,15.0,'AccuWeather'),
('2026-03-10','oeste',27.2,17.8,'AccuWeather'),
('2026-03-14','oeste',30.0,17.8,'AccuWeather'),
('2026-03-15','oeste',29.4,16.7,'AccuWeather'),
('2026-03-16','oeste',28.9,15.6,'AccuWeather'),
-- Este (Maldonado)
('2026-01-04','este',26.1,14.4,'AccuWeather'),
('2026-01-25','este',33.3,20.0,'AccuWeather'),
('2026-01-26','este',33.3,20.0,'AccuWeather'),
('2026-02-01','este',27.2,17.2,'AccuWeather'),
('2026-02-19','este',25.0,18.3,'AccuWeather'),
('2026-03-07','este',26.1,16.7,'AccuWeather'),
('2026-03-08','este',23.9,17.2,'AccuWeather'),
('2026-03-09','este',25.6,18.9,'AccuWeather'),
('2026-03-10','este',25.0,19.4,'AccuWeather'),
('2026-03-14','este',28.9,21.7,'AccuWeather'),
('2026-03-15','este',28.3,21.7,'AccuWeather'),
('2026-03-16','este',25.0,17.8,'AccuWeather'),
-- Sur (Colonia/ref)
('2026-01-04','sur',27.2,19.4,'AccuWeather'),
('2026-01-25','sur',35.6,22.8,'AccuWeather'),
('2026-01-26','sur',35.6,22.8,'AccuWeather'),
('2026-02-01','sur',29.4,18.9,'AccuWeather'),
('2026-02-19','sur',27.2,19.4,'AccuWeather'),
('2026-03-07','sur',24.9,20.0,'AccuWeather'),
('2026-03-08','sur',24.9,17.8,'AccuWeather'),
('2026-03-09','sur',24.9,17.2,'AccuWeather'),
('2026-03-10','sur',25.9,15.0,'AccuWeather'),
('2026-03-14','sur',28.1,13.9,'AccuWeather'),
('2026-03-15','sur',33.2,17.2,'AccuWeather'),
('2026-03-16','sur',32.7,22.2,'AccuWeather')
ON CONFLICT (fecha, zona) DO NOTHING;
