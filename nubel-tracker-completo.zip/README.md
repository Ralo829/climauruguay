# Nubel Tracker — Setup Completo

Sistema automático para contrastar pronósticos de Nubel Cisneros (Canal 10/Subrayado)
con datos reales de INUMET/Open-Meteo. Se actualiza todos los días a las 12:00 Uruguay.

---

## Arquitectura

```
GitHub Actions (cron 12:00 UY)
        ↓
  nubel_scraper.py
  ├── Scrape Subrayado.com.uy → pronósticos Nubel
  └── Open-Meteo Archive API → datos reales INUMET
        ↓
   Supabase (PostgreSQL)
   ├── nubel_pronosticos
   └── datos_reales
        ↓
  React App (claude.ai artifact)
  └── Lee Supabase via REST (anon key)
```

---

## Paso 1 — Crear proyecto en Supabase

1. Ir a https://supabase.com → "New project"
2. Nombre: `nubel-tracker`
3. Guardar la **Database Password** (no la necesitarás más)
4. Esperar ~2 minutos a que el proyecto esté listo

### Obtener credenciales

En el dashboard de Supabase → **Settings → API**:

- `Project URL` → es tu `SUPABASE_URL`
  - Ej: `https://abcdefghijkl.supabase.co`
- `anon public` key → es tu `SUPABASE_ANON_KEY` (para la app React, lectura pública)
- `service_role` key → es tu `SUPABASE_SERVICE_KEY` (para el scraper, escritura)

⚠️ **Nunca expongas el `service_role` key en el frontend**

---

## Paso 2 — Crear las tablas en Supabase

1. En Supabase → **SQL Editor** → "New query"
2. Copiar el contenido completo de `supabase/schema.sql`
3. Hacer click en **Run**

Esto crea las tablas, índices, RLS policies, y carga los datos históricos.

---

## Paso 3 — Crear el repositorio en GitHub

```bash
# Crear repo (puede ser privado)
gh repo create nubel-tracker --private --clone
cd nubel-tracker

# Copiar los archivos
cp -r /ruta/al/proyecto/* .

# Commit inicial
git add .
git commit -m "Initial setup"
git push
```

### Agregar Secrets en GitHub

En el repositorio → **Settings → Secrets and variables → Actions → New repository secret**:

| Secret Name | Valor |
|-------------|-------|
| `SUPABASE_URL` | `https://abcdefghijkl.supabase.co` |
| `SUPABASE_SERVICE_KEY` | La `service_role` key de Supabase |

---

## Paso 4 — Configurar la app React

En el archivo `app/nubel-tracker.jsx`, reemplazar las líneas 7-8:

```javascript
const SUPABASE_URL  = "https://TU_PROYECTO.supabase.co";   // ← tu URL
const SUPABASE_ANON = "TU_ANON_KEY";                        // ← anon key
```

Luego subir el artifact a claude.ai o publicarlo como React app.

---

## Paso 5 — Verificar que funciona

### Probar el scraper manualmente

En GitHub → **Actions → Nubel Tracker — Scraper Diario → Run workflow**

Debería completarse en ~2-3 minutos y agregar datos nuevos a Supabase.

### Verificar en Supabase

```sql
-- Ver últimos pronósticos cargados
SELECT * FROM nubel_pronosticos ORDER BY created_at DESC LIMIT 10;

-- Ver últimos datos reales
SELECT * FROM datos_reales ORDER BY created_at DESC LIMIT 10;

-- Ver log del scraper
SELECT * FROM scraper_log ORDER BY ejecutado_en DESC LIMIT 5;
```

---

## Cron Schedule

El workflow corre automáticamente:
- **15:00 UTC = 12:00 Uruguay (UTC-3)**
- Todos los días del año

```yaml
schedule:
  - cron: "0 15 * * *"
```

Nota: En horario de verano Uruguay puede ser UTC-2, ajustar a `cron: "0 14 * * *"` si es necesario.

---

## Cómo funciona el scraper

Cada día a las 12:00 el scraper hace lo siguiente:

1. **Pronósticos**: Scrapea los 5 artículos más recientes de
   `subrayado.com.uy/nubel-cisneros-a12869` y extrae temperaturas
   por zona (Norte, Sur, Este, Oeste, Área Metropolitana).

2. **Datos reales**: Consulta Open-Meteo Archive para las estaciones INUMET
   de ayer y anteayer (ya disponibles con 2 días de retraso).

3. **Upsert a Supabase**: Inserta o actualiza los registros usando
   la constraint UNIQUE(fecha, zona), evitando duplicados.

4. **Log**: Registra el resultado en `scraper_log` para auditoría.

---

## Estructura de archivos

```
nubel-tracker/
├── .github/
│   └── workflows/
│       └── scraper.yml          # GitHub Actions cron
├── scraper/
│   ├── nubel_scraper.py         # Script principal
│   └── requirements.txt         # Dependencies Python
├── supabase/
│   └── schema.sql               # Schema + datos seed
├── app/
│   └── nubel-tracker.jsx        # React app (lee Supabase)
└── README.md
```

---

## Costo estimado

- **Supabase Free tier**: 500MB storage, 2GB bandwidth/mes → más que suficiente
- **GitHub Actions Free**: 2000 min/mes (el scraper usa ~3 min/día = 90 min/mes)
- **Open-Meteo**: API gratuita, sin key requerida
- **Total: $0/mes**
