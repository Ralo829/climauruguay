import { useState, useEffect, useMemo } from "react";

// ─── SUPABASE CONFIG ─────────────────────────────────────────────────────────
// Reemplazar con tus valores reales de Supabase
const SUPABASE_URL  = "https://TU_PROYECTO.supabase.co";
const SUPABASE_ANON = "TU_ANON_KEY";

async function supaFetch(table, params = "") {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${table}?${params}&limit=1000`,
    {
      headers: {
        apikey: SUPABASE_ANON,
        Authorization: `Bearer ${SUPABASE_ANON}`,
      },
    }
  );
  if (!res.ok) throw new Error(`Supabase ${res.status}: ${await res.text()}`);
  return res.json();
}

// ─── ZONAS ───────────────────────────────────────────────────────────────────
const ZONAS = {
  metro: { label: "Montevideo", color: "#fbbf24", ref: "Carrasco · Prado" },
  norte: { label: "Norte",      color: "#f97316", ref: "Salto" },
  oeste: { label: "Oeste",      color: "#34d399", ref: "Paysandú" },
  este:  { label: "Este",       color: "#a78bfa", ref: "Maldonado" },
  sur:   { label: "Sur",        color: "#38bdf8", ref: "Colonia (ref.)" },
};
const ZONA_KEYS = Object.keys(ZONAS);

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const MES = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
const fmtDate = s => { const [,m,d] = s.split("-"); return `${+d} ${MES[+m-1]}`; };
const fmtDateLong = s => {
  const [y,m,d] = s.split("-");
  return `${+d} ${MES[+m-1]} ${y}`;
};
const avg = arr => arr.length ? +(arr.reduce((s,v)=>s+v,0)/arr.length).toFixed(1) : null;

const difColor = d => {
  if (d === null) return "#475569";
  if (d > 0) return "#38bdf8";
  if (d < 0) return "#ef4444";
  return "#22c55e";
};
const difBg = d => {
  if (d === null) return "transparent";
  if (d > 0) return "rgba(56,189,248,0.1)";
  if (d < 0) return "rgba(239,68,68,0.1)";
  return "rgba(34,197,94,0.1)";
};
const difLabel = d => {
  if (d === null) return "";
  if (d > 3)    return "Sobreestimó";
  if (d > 1.5)  return "Algo alto";
  if (d < -3)   return "Subestimó";
  if (d < -1.5) return "Algo bajo";
  if (d === 0)  return "Exacto";
  return d > 0 ? "Algo alto" : "Algo bajo";
};

function calcStats(rows) {
  const pairs = rows.filter(r => r.difMax !== null);
  if (!pairs.length) return null;
  return {
    total:      pairs.length,
    avgDifMax:  avg(pairs.map(r => r.difMax)),
    avgDifMin:  avg(pairs.filter(r=>r.difMin!==null).map(r => r.difMin)),
    precisos:   pairs.filter(r => Math.abs(r.difMax) <= 1.5).length,
    sobreEst:   pairs.filter(r => r.difMax > 1.5).length,
    subEst:     pairs.filter(r => r.difMax < -1.5).length,
  };
}

// ─── COMPONENTES PEQUEÑOS ─────────────────────────────────────────────────
function InfoLink({ href, title }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" title={title}
      style={{ display:"inline-flex",alignItems:"center",justifyContent:"center",
        width:16,height:16,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.2)",
        color:"rgba(255,255,255,0.35)",fontSize:9,fontWeight:800,fontFamily:"serif",
        textDecoration:"none",flexShrink:0,marginLeft:5,lineHeight:1,transition:"all .15s" }}
      onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.6)";e.currentTarget.style.color="#fff";e.currentTarget.style.background="rgba(255,255,255,0.1)";}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.2)";e.currentTarget.style.color="rgba(255,255,255,0.35)";e.currentTarget.style.background="transparent";}}
    >i</a>
  );
}

function DifCell({ val, size = 20 }) {
  if (val === null || val === undefined) return <span style={{color:"#334155"}}>—</span>;
  return (
    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:size, fontWeight:800,
      color: val>0?"#38bdf8":val<0?"#ef4444":"#22c55e" }}>
      {val>0?`+${val}`:val}°
    </span>
  );
}

function KpiBox({ label, value, sub, color }) {
  return (
    <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:12,padding:"12px 14px" }}>
      <div style={{ fontSize:9,color:"#334155",textTransform:"uppercase",letterSpacing:1,marginBottom:4 }}>{label}</div>
      <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:24,fontWeight:900,color,lineHeight:1 }}>{value}</div>
      {sub && <div style={{ fontSize:9,color:"#475569",marginTop:4 }}>{sub}</div>}
    </div>
  );
}

function Tooltip({ text }) {
  const [show, setShow] = useState(false);
  return (
    <span style={{ position:"relative",display:"inline-block",marginLeft:5,cursor:"help" }}
      onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)}>
      <span style={{ display:"inline-flex",alignItems:"center",justifyContent:"center",
        width:14,height:14,borderRadius:"50%",border:"1px solid rgba(255,255,255,0.2)",
        color:"rgba(255,255,255,0.35)",fontSize:8,fontWeight:800,fontFamily:"serif" }}>?</span>
      {show && (
        <div style={{ position:"absolute",bottom:"calc(100% + 6px)",left:"50%",transform:"translateX(-50%)",
          background:"#0f1e35",border:"1px solid rgba(255,255,255,0.12)",borderRadius:10,
          padding:"10px 14px",width:260,zIndex:100,fontSize:11,color:"#94a3b8",lineHeight:1.6,
          boxShadow:"0 8px 32px rgba(0,0,0,0.5)" }}>
          {text}
        </div>
      )}
    </span>
  );
}

function PrecisionExplanation() {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop:20,border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,overflow:"hidden" }}>
      <button onClick={()=>setOpen(!open)} style={{
        width:"100%",padding:"12px 16px",background:"rgba(255,255,255,0.03)",
        border:"none",textAlign:"left",color:"#94a3b8",fontSize:12,fontWeight:600,
        display:"flex",alignItems:"center",justifyContent:"space-between",fontFamily:"inherit",cursor:"pointer" }}>
        <span>¿Cómo se calcula la precisión?</span>
        <span style={{fontSize:14,color:"#475569"}}>{open?"▲":"▼"}</span>
      </button>
      {open && (
        <div style={{ padding:"14px 16px",fontSize:12,color:"#64748b",lineHeight:1.8,borderTop:"1px solid rgba(255,255,255,0.06)" }}>
          <p style={{marginBottom:10}}>
            <strong style={{color:"#94a3b8"}}>Dif</strong> = Temperatura pronosticada por Nubel − Temperatura real registrada por INUMET.
          </p>
          <p style={{marginBottom:10}}>
            <strong style={{color:"#38bdf8"}}>Celeste (positivo)</strong>: Nubel sobreestimó.{" "}
            <strong style={{color:"#ef4444"}}>Rojo (negativo)</strong>: Nubel subestimó.
          </p>
          <p style={{marginBottom:10}}>
            <strong style={{color:"#94a3b8"}}>Precisión</strong> = % de días con diferencia de máxima ≤ ±1.5°C. Umbral estándar en meteorología regional.
          </p>
          <p>
            <strong style={{color:"#94a3b8"}}>Promedio Dif</strong> = suma de diferencias / días. Positivo = tendencia a sobreestimar.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENTE PRINCIPAL ────────────────────────────────────────────────────
export default function App() {
  // Estado de datos
  const [pronosticos, setPronosticos] = useState([]);
  const [reales,      setReales]      = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // UI state
  const [activeTab, setActiveTab] = useState("metro");
  const [dateFrom,  setDateFrom]  = useState("");
  const [dateTo,    setDateTo]    = useState("");
  const [preset,    setPreset]    = useState("todos");

  const TEMP_SIZE = 22;

  // ─── CARGA DE DATOS ──────────────────────────────────────────────────────
  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const [pron, real] = await Promise.all([
          supaFetch("nubel_pronosticos", "select=fecha_dia,fecha_pronostico,zona,max_nubel,min_nubel,url_fuente&order=fecha_dia.desc"),
          supaFetch("datos_reales",      "select=fecha,zona,max_real,min_real,fuente&order=fecha.desc"),
        ]);
        setPronosticos(pron);
        setReales(real);
        setLastUpdated(new Date().toLocaleTimeString("es-UY"));

        // Establecer rango por defecto con las fechas disponibles
        if (pron.length) {
          const fechas = pron.map(r => r.fecha_dia).sort();
          setDateFrom(fechas[0]);
          setDateTo(fechas[fechas.length - 1]);
        }
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }
    load();
    // Refrescar cada 30 min
    const interval = setInterval(load, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  // ─── ÍNDICES ─────────────────────────────────────────────────────────────
  const realIdx = useMemo(() => {
    const idx = {};
    for (const r of reales) {
      if (!idx[r.fecha]) idx[r.fecha] = {};
      idx[r.fecha][r.zona] = r;
    }
    return idx;
  }, [reales]);

  // Fechas únicas disponibles
  const allDates = useMemo(() =>
    [...new Set(pronosticos.map(p => p.fecha_dia))].sort(),
    [pronosticos]
  );
  const minDate = allDates[0] ?? "";
  const maxDate = allDates[allDates.length - 1] ?? "";

  // Aplicar presets
  const applyPreset = (p) => {
    setPreset(p);
    const today = new Date().toISOString().split("T")[0];
    const ayer  = new Date(Date.now() - 86400000).toISOString().split("T")[0];
    const hace7 = new Date(Date.now() - 7*86400000).toISOString().split("T")[0];
    const hace30= new Date(Date.now() - 30*86400000).toISOString().split("T")[0];
    if (p === "todos")    { setDateFrom(minDate); setDateTo(maxDate); }
    if (p === "ayer")     { setDateFrom(ayer);    setDateTo(ayer); }
    if (p === "ultimos7") { setDateFrom(hace7);   setDateTo(today); }
    if (p === "ultimo_mes"){ setDateFrom(hace30); setDateTo(today); }
  };

  // Filas filtradas por rango y zona activa
  const isGeneral = activeTab === "general";
  const zona = isGeneral ? null : activeTab;

  const filteredDates = useMemo(() =>
    allDates.filter(d => (!dateFrom || d >= dateFrom) && (!dateTo || d <= dateTo)),
    [allDates, dateFrom, dateTo]
  );

  // Construir tableRows para zona activa
  const tableRows = useMemo(() => {
    if (isGeneral || !zona) return [];
    return filteredDates.map(fecha => {
      const prons = pronosticos.filter(p => p.fecha_dia === fecha && p.zona === zona);
      const p     = prons[0];
      const real  = realIdx[fecha]?.[zona];
      const difMax = p?.max_nubel != null && real?.max_real != null
        ? +(p.max_nubel - real.max_real).toFixed(1) : null;
      const difMin = p?.min_nubel != null && real?.min_real != null
        ? +(p.min_nubel - real.min_real).toFixed(1) : null;
      return {
        fecha,
        fPron:     p?.fecha_pronostico,
        nubel:     p ? { max: p.max_nubel, min: p.min_nubel } : null,
        real:      real ? { max: real.max_real, min: real.min_real } : null,
        urlNubel:  p?.url_fuente,
        difMax,
        difMin,
      };
    });
  }, [filteredDates, pronosticos, realIdx, zona, isGeneral]);

  const stats = useMemo(() => calcStats(tableRows), [tableRows]);

  // Stats general (todas las zonas)
  const generalStats = useMemo(() => {
    if (!isGeneral) return [];
    return ZONA_KEYS.map(z => {
      const rows = filteredDates.map(fecha => {
        const p    = pronosticos.find(pr => pr.fecha_dia === fecha && pr.zona === z);
        const real = realIdx[fecha]?.[z];
        return {
          difMax: p?.max_nubel != null && real?.max_real != null
            ? +(p.max_nubel - real.max_real).toFixed(1) : null,
          difMin: p?.min_nubel != null && real?.min_real != null
            ? +(p.min_nubel - real.min_real).toFixed(1) : null,
        };
      });
      return { zona: z, ...calcStats(rows) };
    });
  }, [isGeneral, filteredDates, pronosticos, realIdx]);

  const globalAvgMax = useMemo(() =>
    avg(generalStats.filter(s=>s?.avgDifMax!=null).map(s=>s.avgDifMax)),
    [generalStats]
  );
  const globalAvgMin = useMemo(() =>
    avg(generalStats.filter(s=>s?.avgDifMin!=null).map(s=>s.avgDifMin)),
    [generalStats]
  );

  const Z = !isGeneral ? ZONAS[zona] : null;

  const PRESETS = [
    { key:"todos",       label:"Todo el período" },
    { key:"ayer",        label:"Ayer" },
    { key:"ultimos7",    label:"Últimos 7 días" },
    { key:"ultimo_mes",  label:"Último mes" },
  ];

  // ─── RENDER ──────────────────────────────────────────────────────────────
  if (loading && !pronosticos.length) {
    return (
      <div style={{ minHeight:"100vh",background:"#07101e",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:16 }}>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
        <div style={{ width:40,height:40,border:"3px solid rgba(251,191,36,0.2)",borderTopColor:"#fbbf24",borderRadius:"50%",animation:"spin .7s linear infinite" }}/>
        <div style={{ color:"#475569",fontSize:13,fontFamily:"'Outfit',sans-serif" }}>Cargando datos desde Supabase…</div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ minHeight:"100vh",background:"#07101e",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:12,padding:20 }}>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
        <div style={{ fontSize:32 }}>⚠️</div>
        <div style={{ color:"#ef4444",fontSize:14,fontFamily:"'Outfit',sans-serif",textAlign:"center",maxWidth:400 }}>
          Error conectando a Supabase: {error}
        </div>
        <div style={{ color:"#475569",fontSize:11,fontFamily:"'JetBrains Mono',monospace",textAlign:"center" }}>
          Verificá que SUPABASE_URL y SUPABASE_ANON estén configurados correctamente en el código.
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight:"100vh",background:"#07101e",color:"#e2e8f0",fontFamily:"'Outfit','Helvetica Neue',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
      <style>{`
        *{box-sizing:border-box;margin:0;padding:0}
        body{-webkit-text-size-adjust:100%}
        ::-webkit-scrollbar{width:3px;height:3px}::-webkit-scrollbar-thumb{background:#1e293b}
        button{cursor:pointer;font-family:inherit;transition:all .15s;-webkit-tap-highlight-color:transparent}
        input[type=date]{color-scheme:dark}
        .strip{display:flex;overflow-x:auto;gap:6px;scrollbar-width:none}.strip::-webkit-scrollbar{display:none}
        .trow:hover{background:rgba(255,255,255,0.04)!important}
        @keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .fade{animation:fadeUp .3s ease both}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>

      {/* HEADER */}
      <div style={{ background:"rgba(255,255,255,0.025)",borderBottom:"1px solid rgba(255,255,255,0.07)",padding:"16px 16px 0" }}>
        <div style={{ maxWidth:720,margin:"0 auto" }}>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14 }}>
            <div>
              <div style={{ fontSize:10,letterSpacing:2.5,color:"#334155",textTransform:"uppercase",marginBottom:4 }}>
                Canal 10 · Subrayado · 2026
              </div>
              <h1 style={{ fontSize:26,fontWeight:900,letterSpacing:-0.5,lineHeight:1.1 }}>
                Nubel <span style={{ color: isGeneral?"#94a3b8":Z.color }}>vs</span> Realidad
              </h1>
            </div>
            <div style={{ textAlign:"right",paddingTop:4 }}>
              <div style={{ fontSize:9,color:"#334155",textTransform:"uppercase",letterSpacing:1 }}>
                {pronosticos.length} pronósticos · {reales.length} reales
              </div>
              {lastUpdated && (
                <div style={{ fontSize:9,color:"#22c55e",marginTop:2 }}>
                  ✓ Actualizado {lastUpdated}
                </div>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="strip">
            <button onClick={()=>setActiveTab("general")} style={{
              flexShrink:0,padding:"9px 16px",borderRadius:"10px 10px 0 0",fontFamily:"inherit",
              border:`1px solid #94a3b8${activeTab==="general"?"70":"25"}`,
              borderBottom:activeTab==="general"?"1px solid #07101e":"1px solid transparent",
              background:activeTab==="general"?"#07101e":"transparent",
              color:activeTab==="general"?"#e2e8f0":"#475569",
              fontWeight:activeTab==="general"?700:500,fontSize:13,
              position:"relative",zIndex:activeTab==="general"?2:1,
              marginBottom:activeTab==="general"?-1:0,
            }}>🌐 General</button>
            {ZONA_KEYS.map(k => (
              <button key={k} onClick={()=>setActiveTab(k)} style={{
                flexShrink:0,padding:"9px 16px",borderRadius:"10px 10px 0 0",fontFamily:"inherit",
                border:`1px solid ${ZONAS[k].color}${activeTab===k?"70":"25"}`,
                borderBottom:activeTab===k?"1px solid #07101e":"1px solid transparent",
                background:activeTab===k?"#07101e":"transparent",
                color:activeTab===k?ZONAS[k].color:"#475569",
                fontWeight:activeTab===k?700:500,fontSize:13,
                position:"relative",zIndex:activeTab===k?2:1,
                marginBottom:activeTab===k?-1:0,
              }}>{ZONAS[k].label}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:720,margin:"0 auto",padding:"20px 12px 60px" }}>

        {/* FILTRO FECHAS */}
        <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"14px 16px",marginBottom:20 }}>
          <div style={{ fontSize:10,color:"#475569",textTransform:"uppercase",letterSpacing:1.5,marginBottom:10 }}>Rango de fechas</div>
          <div style={{ display:"flex",gap:6,flexWrap:"wrap",marginBottom:12 }}>
            {PRESETS.map(p => (
              <button key={p.key} onClick={()=>applyPreset(p.key)} style={{
                padding:"5px 12px",borderRadius:20,fontSize:11,fontWeight:preset===p.key?700:400,
                border:`1px solid ${preset===p.key?"rgba(255,255,255,0.3)":"rgba(255,255,255,0.1)"}`,
                background:preset===p.key?"rgba(255,255,255,0.1)":"transparent",
                color:preset===p.key?"#f1f5f9":"#475569",
              }}>{p.label}</button>
            ))}
          </div>
          <div style={{ display:"flex",gap:10,alignItems:"center",flexWrap:"wrap" }}>
            {[["Desde",dateFrom,minDate,dateTo,setDateFrom],["Hasta",dateTo,dateFrom,maxDate,setDateTo]].map(([lbl,val,mn,mx,set])=>(
              <div key={lbl} style={{ display:"flex",flexDirection:"column",gap:3 }}>
                <label style={{ fontSize:9,color:"#334155",textTransform:"uppercase",letterSpacing:1 }}>{lbl}</label>
                <input type="date" value={val} min={mn} max={mx}
                  onChange={e=>{set(e.target.value);setPreset("custom");}}
                  style={{ background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:8,padding:"6px 10px",color:"#e2e8f0",fontSize:13,outline:"none" }}/>
              </div>
            ))}
            <div style={{ paddingTop:16,fontSize:11,color:"#475569" }}>
              {filteredDates.length} día{filteredDates.length!==1?"s":""} en rango
            </div>
          </div>
        </div>

        {/* ═══ GENERAL ═══════════════════════════════════════════════════════ */}
        {isGeneral && (
          <div>
            {/* KPIs globales */}
            <div className="fade" style={{
              background:globalAvgMax!=null?difBg(globalAvgMax):"rgba(255,255,255,0.03)",
              border:`1px solid ${globalAvgMax!=null?difColor(globalAvgMax)+"50":"rgba(255,255,255,0.07)"}`,
              borderRadius:16,padding:"16px 20px",marginBottom:14,
              display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,
            }}>
              <div>
                <div style={{ display:"flex",alignItems:"center",fontSize:9,color:"#475569",textTransform:"uppercase",letterSpacing:1.5,marginBottom:4 }}>
                  Promedio Dif Máxima — todas las zonas
                  <Tooltip text="Promedio de (Nubel − Real) en temperatura máxima. Celeste = sobreestimó. Rojo = subestimó."/>
                </div>
                <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:48,fontWeight:900,lineHeight:1,
                  color:globalAvgMax!=null?difColor(globalAvgMax):"#334155" }}>
                  {globalAvgMax!=null?`${globalAvgMax>0?"+":""}${globalAvgMax}°`:"—"}
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ display:"flex",alignItems:"center",justifyContent:"flex-end",fontSize:9,color:"#475569",textTransform:"uppercase",letterSpacing:1.5,marginBottom:4 }}>
                  Promedio Dif Mínima
                  <Tooltip text="Promedio de (Nubel − Real) en temperatura mínima."/>
                </div>
                <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:48,fontWeight:900,lineHeight:1,
                  color:globalAvgMin!=null?difColor(globalAvgMin):"#334155" }}>
                  {globalAvgMin!=null?`${globalAvgMin>0?"+":""}${globalAvgMin}°`:"—"}
                </div>
              </div>
            </div>

            {/* Tabla por zonas */}
            <div style={{ border:"1px solid rgba(255,255,255,0.08)",borderRadius:14,overflow:"hidden",marginBottom:20 }}>
              <div style={{ display:"grid",gridTemplateColumns:"1.2fr 1fr 1fr 1fr 1fr 1fr",
                background:"rgba(255,255,255,0.04)",borderBottom:"1px solid rgba(255,255,255,0.08)",
                padding:"10px 16px",gap:8 }}>
                {[
                  { h:"Zona" },
                  { h:"Prom Dif Máx", tip:"Dif promedio temperatura máxima (Nubel − Real)." },
                  { h:"Prom Dif Mín", tip:"Dif promedio temperatura mínima (Nubel − Real)." },
                  { h:"Precisión",    tip:"% días con dif máxima ≤ ±1.5°C." },
                  { h:"Sobre >1.5°",  tip:"Días en que Nubel sobreestimó la máxima." },
                  { h:"Bajo >1.5°",   tip:"Días en que Nubel subestimó la máxima." },
                ].map(({h,tip})=>(
                  <div key={h} style={{ display:"flex",alignItems:"center" }}>
                    <span style={{ fontSize:11,fontWeight:700,color:"#94a3b8" }}>{h}</span>
                    {tip && <Tooltip text={tip}/>}
                  </div>
                ))}
              </div>

              {generalStats.map((s,idx)=>{
                const Zk = ZONAS[s.zona];
                const pct = s?.total ? `${Math.round(s.precisos/s.total*100)}%` : "—";
                return (
                  <div key={s.zona} style={{
                    display:"grid",gridTemplateColumns:"1.2fr 1fr 1fr 1fr 1fr 1fr",
                    padding:"14px 16px",gap:8,alignItems:"center",
                    borderBottom:idx<generalStats.length-1?"1px solid rgba(255,255,255,0.05)":"none",
                  }}>
                    <div>
                      <div style={{ fontSize:13,fontWeight:700,color:Zk.color }}>{Zk.label}</div>
                      <div style={{ fontSize:9,color:"#334155",marginTop:1 }}>{Zk.ref}</div>
                    </div>
                    <DifCell val={s?.avgDifMax}/>
                    <DifCell val={s?.avgDifMin}/>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#22c55e" }}>{pct}</span>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#38bdf8" }}>{s?.sobreEst??0}</span>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#ef4444" }}>{s?.subEst??0}</span>
                  </div>
                );
              })}

              {/* Fila total */}
              <div style={{ display:"grid",gridTemplateColumns:"1.2fr 1fr 1fr 1fr 1fr 1fr",
                padding:"14px 16px",gap:8,alignItems:"center",
                background:"rgba(255,255,255,0.04)",borderTop:"1px solid rgba(255,255,255,0.08)" }}>
                <div style={{ fontSize:12,fontWeight:800,color:"#94a3b8" }}>GLOBAL</div>
                <DifCell val={globalAvgMax}/>
                <DifCell val={globalAvgMin}/>
                <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#22c55e" }}>
                  {generalStats[0]?.total
                    ? `${Math.round(generalStats.reduce((s,gs)=>s+(gs?.precisos||0)/(gs?.total||1),0)/generalStats.length*100)}%`
                    : "—"}
                </span>
                <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#38bdf8" }}>
                  {generalStats.reduce((s,gs)=>s+(gs?.sobreEst||0),0)}
                </span>
                <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:20,fontWeight:800,color:"#ef4444" }}>
                  {generalStats.reduce((s,gs)=>s+(gs?.subEst||0),0)}
                </span>
              </div>
            </div>

            <PrecisionExplanation/>
          </div>
        )}

        {/* ═══ ZONA INDIVIDUAL ════════════════════════════════════════════════ */}
        {!isGeneral && (
          <div>
            <div style={{ fontSize:11,color:"#475569",marginBottom:16 }}>
              <span style={{ color:Z.color,fontWeight:700 }}>{Z.label}</span>
              {" — "}{Z.ref}
            </div>

            {/* KPIs Dif Máxima + Mínima */}
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14 }}>
              {[
                { label:"Promedio Dif Máxima", val:stats?.avgDifMax,
                  tip:"Promedio de (Nubel máx − Real máx). Celeste = sobreestimó.",
                  desc: stats?.avgDifMax==null?"Sin datos" :
                        stats.avgDifMax>0?`Nubel sobreestimó ${stats.avgDifMax}° en promedio` :
                        stats.avgDifMax<0?`Nubel subestimó ${Math.abs(stats.avgDifMax)}° en promedio` :
                        "Nubel acertó exacto" },
                { label:"Promedio Dif Mínima",  val:stats?.avgDifMin,
                  tip:"Promedio de (Nubel mín − Real mín).",
                  desc: stats?.avgDifMin==null?"Sin datos" :
                        stats.avgDifMin>0?`Nubel sobreestimó ${stats.avgDifMin}° en mínimas`:
                        stats.avgDifMin<0?`Nubel subestimó ${Math.abs(stats.avgDifMin)}° en mínimas`:
                        "Nubel acertó exacto" },
              ].map(({label,val,tip,desc})=>(
                <div key={label} className="fade" style={{
                  background:val!=null?difBg(val):"rgba(255,255,255,0.03)",
                  border:`1px solid ${val!=null?difColor(val)+"50":"rgba(255,255,255,0.07)"}`,
                  borderRadius:14,padding:"14px 16px",
                }}>
                  <div style={{ display:"flex",alignItems:"center",fontSize:9,color:"#475569",textTransform:"uppercase",letterSpacing:1.5,marginBottom:6 }}>
                    {label}<Tooltip text={tip}/>
                  </div>
                  <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:44,fontWeight:900,lineHeight:1,
                    color:val!=null?difColor(val):"#334155" }}>
                    {val!=null?`${val>0?"+":""}${val}°`:"—"}
                  </div>
                  <div style={{ fontSize:11,color:"#475569",marginTop:5 }}>{desc}</div>
                </div>
              ))}
            </div>

            {/* KPIs secundarios */}
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:24 }}>
              <KpiBox label="Precisión ≤1.5°" value={stats?.total?`${Math.round(stats.precisos/stats.total*100)}%`:"—"}
                sub={`${stats?.precisos??0} de ${stats?.total??0} días`} color="#22c55e"/>
              <KpiBox label="Sobreestimados" value={stats?.sobreEst??0} sub="Dif máx > +1.5°" color="#38bdf8"/>
              <KpiBox label="Subestimados"   value={stats?.subEst??0}   sub="Dif máx < −1.5°" color="#ef4444"/>
            </div>

            {/* TABLA */}
            <div style={{ border:"1px solid rgba(255,255,255,0.08)",borderRadius:14,overflow:"hidden" }}>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",
                background:"rgba(255,255,255,0.04)",borderBottom:"1px solid rgba(255,255,255,0.08)",
                padding:"10px 16px",gap:8 }}>
                {[{h:"Día",s:"fecha"},{h:"Nubel",s:"pronóst. día anterior"},{h:"Real",s:"AccuWeather/INUMET"},{h:"Dif",s:"Nubel − Real"}]
                  .map(({h,s})=>(
                    <div key={h}>
                      <div style={{ fontSize:13,fontWeight:700,color:"#94a3b8" }}>{h}</div>
                      <div style={{ fontSize:9,color:"#334155",textTransform:"uppercase",letterSpacing:0.8,marginTop:1 }}>{s}</div>
                    </div>
                  ))}
              </div>

              {tableRows.length === 0 && (
                <div style={{ padding:"32px 16px",textAlign:"center",color:"#334155",fontSize:13 }}>
                  {loading ? "Cargando…" : "Sin datos para el rango seleccionado"}
                </div>
              )}

              {tableRows.map((row,idx)=>{
                const { fecha,fPron,nubel,real,difMax,difMin,urlNubel } = row;
                return (
                  <div key={fecha} className="trow" style={{
                    display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",
                    padding:"16px 16px",gap:8,alignItems:"center",
                    borderBottom:idx<tableRows.length-1?"1px solid rgba(255,255,255,0.05)":"none",
                    background:"transparent",transition:"background .15s",
                  }}>
                    <div>
                      <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:15,fontWeight:700,color:"#ffffff" }}>
                        {fmtDate(fecha)}
                      </div>
                      <div style={{ fontSize:9,color:"#334155",marginTop:2 }}>
                        pronóst. {fPron ? fmtDate(fPron) : "—"}
                      </div>
                    </div>
                    <div>
                      <div style={{ display:"flex",alignItems:"center" }}>
                        <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:700,color:"#f97316" }}>
                          {nubel?.max!=null?`${nubel.max}°`:"—"}
                        </span>
                        {urlNubel && <InfoLink href={urlNubel} title="Ver pronóstico en Subrayado"/>}
                      </div>
                      <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:700,color:"#f97316",marginTop:4 }}>
                        {nubel?.min!=null?`${nubel.min}°`:"—"}
                      </div>
                      <div style={{ fontSize:9,color:"#475569",marginTop:3 }}>máx · mín</div>
                    </div>
                    <div>
                      <div style={{ display:"flex",alignItems:"center" }}>
                        <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:700,color:"#22c55e" }}>
                          {real?.max!=null?`${real.max}°`:"—"}
                        </span>
                      </div>
                      <div style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:700,color:"#22c55e",marginTop:4 }}>
                        {real?.min!=null?`${real.min}°`:"—"}
                      </div>
                      <div style={{ fontSize:9,color:"#475569",marginTop:3 }}>máx · mín</div>
                    </div>
                    <div>
                      {difMax!==null ? (
                        <div style={{ display:"inline-flex",flexDirection:"column",alignItems:"center",
                          background:difBg(difMax),border:`1px solid ${difColor(difMax)}40`,
                          borderRadius:10,padding:"8px 12px",minWidth:60 }}>
                          <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:900,color:difColor(difMax),lineHeight:1 }}>
                            {difMax>0?`+${difMax}`:difMax}°
                          </span>
                          {difMin!==null && (
                            <span style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:TEMP_SIZE,fontWeight:700,color:difColor(difMin),marginTop:4,lineHeight:1 }}>
                              {difMin>0?`+${difMin}`:difMin}°
                            </span>
                          )}
                          <span style={{ fontSize:8,color:difColor(difMax),fontWeight:700,marginTop:5,textTransform:"uppercase",letterSpacing:0.5 }}>
                            {difLabel(difMax)}
                          </span>
                        </div>
                      ) : <span style={{ color:"#334155",fontSize:12 }}>—</span>}
                    </div>
                  </div>
                );
              })}
            </div>

            <PrecisionExplanation/>
          </div>
        )}

        <div style={{ marginTop:24,fontSize:9,color:"#1e293b",lineHeight:1.8 }}>
          Pronósticos: Subrayado.com.uy (Nubel Cisneros) ·
          Datos reales: Open-Meteo Archive / AccuWeather · Estaciones INUMET Uruguay ·
          Scraper automático diario 12:00 Uruguay
        </div>
      </div>
    </div>
  );
}
